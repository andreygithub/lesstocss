--------------------
Snippet: lesstocss
--------------------
Version: 1.0.0
Released: Feb 04, 2014
Since: Feb 04, 2014
Author: Andrey Zagorets modx.cybershop@gmail.com

About: 
A snippet for returning css from less file. This release requires MODX Revolution 2.1+.

Usage:
use this cintent for chunk this css def.
<link rel="stylesheet" type="text/css" href="[[lesstocss? 
&lessFile=`assets/template/bootstrap/main.less`
&relativeURL=`[[++site_url]]assets/template/bootstrap/`]]">


Official Documentation:
http://rtfm.modx.com/display/ADDON/lesstocss