<?php
require_once (dirname(dirname(__FILE__)) . '/csorderlog.class.php');
class csOrderLog_mysql extends csOrderLog {}