<?php
class csOrderProduct extends xPDOSimpleObject {}