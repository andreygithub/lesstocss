<?php
require_once (dirname(dirname(__FILE__)) . '/cscurrency.class.php');
class csCurrency_mysql extends csCurrency {}