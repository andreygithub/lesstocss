<?php
class csCatalogPropertyTable extends xPDOSimpleObject {}