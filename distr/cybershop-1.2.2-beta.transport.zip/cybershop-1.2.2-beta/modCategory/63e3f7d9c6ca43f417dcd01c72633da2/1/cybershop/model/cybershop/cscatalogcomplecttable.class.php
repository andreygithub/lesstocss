<?php
class csCatalogComplectTable extends xPDOSimpleObject {}