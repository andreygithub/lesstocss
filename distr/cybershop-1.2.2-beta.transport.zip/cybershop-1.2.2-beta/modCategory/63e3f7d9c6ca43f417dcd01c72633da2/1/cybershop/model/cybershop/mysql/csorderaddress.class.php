<?php
require_once (dirname(dirname(__FILE__)) . '/csorderaddress.class.php');
class csOrderAddress_mysql extends csOrderAddress {}