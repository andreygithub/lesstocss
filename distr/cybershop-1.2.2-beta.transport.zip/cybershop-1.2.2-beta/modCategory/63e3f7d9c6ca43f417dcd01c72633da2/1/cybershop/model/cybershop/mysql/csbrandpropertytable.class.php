<?php
require_once (dirname(dirname(__FILE__)) . '/csbrandpropertytable.class.php');
class csBrandPropertyTable_mysql extends csBrandPropertyTable {}