<?php
require_once (dirname(dirname(__FILE__)) . '/csorder.class.php');
class csOrder_mysql extends csOrder {}