<?php
require_once (dirname(dirname(__FILE__)) . '/cscatalogstoretable.class.php');
class csCatalogStoreTable_mysql extends csCatalogStoreTable {}