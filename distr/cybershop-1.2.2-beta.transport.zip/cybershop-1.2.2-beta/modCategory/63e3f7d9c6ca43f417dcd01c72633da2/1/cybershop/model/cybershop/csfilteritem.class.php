<?php
class csFilterItem extends xPDOSimpleObject {}