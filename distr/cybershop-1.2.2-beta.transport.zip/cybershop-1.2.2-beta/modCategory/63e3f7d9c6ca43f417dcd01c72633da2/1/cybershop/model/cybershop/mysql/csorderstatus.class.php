<?php
require_once (dirname(dirname(__FILE__)) . '/csorderstatus.class.php');
class csOrderStatus_mysql extends csOrderStatus {}