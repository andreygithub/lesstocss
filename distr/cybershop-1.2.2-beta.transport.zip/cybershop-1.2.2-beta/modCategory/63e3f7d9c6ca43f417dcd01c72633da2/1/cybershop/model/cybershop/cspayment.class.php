<?php
class csPayment extends xPDOSimpleObject {}