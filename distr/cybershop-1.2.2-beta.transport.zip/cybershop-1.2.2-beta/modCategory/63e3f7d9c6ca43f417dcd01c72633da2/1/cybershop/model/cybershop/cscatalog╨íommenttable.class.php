<?php
class csCatalogСommentTable extends xPDOSimpleObject {}