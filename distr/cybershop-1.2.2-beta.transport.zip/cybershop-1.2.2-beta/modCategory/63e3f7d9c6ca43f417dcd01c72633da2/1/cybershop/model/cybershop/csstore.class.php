<?php
class csStore extends xPDOSimpleObject {}