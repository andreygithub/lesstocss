<?php

class csOrderGetProcessor extends modObjectGetProcessor {
	public $classKey = 'csCatalog';
	public $languageTopics = array('cybershop:default');



}

return 'csOrderGetProcessor';