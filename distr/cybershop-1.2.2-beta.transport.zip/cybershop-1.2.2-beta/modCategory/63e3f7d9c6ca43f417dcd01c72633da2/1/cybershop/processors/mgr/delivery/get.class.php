<?php

class csDeliveryGetProcessor extends modObjectGetProcessor {
	public $classKey = 'csDelivery';
	public $languageTopics = array('cybershop');
	public $objectType = 'cs_delivery';
}

return 'csDeliveryGetProcessor';