<?php

class csPaymentGetProcessor extends modObjectGetProcessor {
	public $classKey = 'csPayment';
	public $languageTopics = array('cybershop');
	public $objectType = 'cs_payment';
}

return 'csPaymentGetProcessor';